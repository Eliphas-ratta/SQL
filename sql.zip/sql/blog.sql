INSERT INTO users ( name, email, password, created_at) VALUES
( 'Alice', 'alice@example.com', 'password123', '2024-01-01'),
('Saddam', 'Hussein.saddam@example.com', 'underground', '2003-04-09'),
( 'Jeffrey', 'Lolita.island@example.com', 'alwaysunder18', '2020-07-02'),
('Pdiddy', 'thebestpartyaround@rap.com', 'Milking22', '2024-04-07'),
( 'Hillary', 'Plsdontleakmyaddress@usagov.com', 'qwerty', '2023-08-03'),
('Osama', 'John.doe@pakistan.com', 'ilovejapan', '2001-09-11');


